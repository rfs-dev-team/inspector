package wtf.imba.inspector.utils

object Config {
    const val SP_USER_HOOKS = "user_hooks"
    const val SP_USER_REPLACES = "user_param_replaces"
    const val SP_USER_RETURN_REPLACES = "user_return_replaces"
    const val SP_DATA_DIR = "path"
}